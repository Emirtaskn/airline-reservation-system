﻿namespace Havayolu
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtKullanici = new TextBox();
            label2 = new Label();
            txtSifre = new TextBox();
            btnGirisYap = new Button();
            btnKayitOl = new Button();
            label3 = new Label();
            label4 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.Location = new Point(527, 345);
            label1.Name = "label1";
            label1.Size = new Size(115, 21);
            label1.TabIndex = 0;
            label1.Text = "Kullanıcı Adı :";
            // 
            // txtKullanici
            // 
            txtKullanici.Location = new Point(673, 343);
            txtKullanici.Name = "txtKullanici";
            txtKullanici.Size = new Size(131, 23);
            txtKullanici.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2.Location = new Point(527, 381);
            label2.Name = "label2";
            label2.Size = new Size(53, 21);
            label2.TabIndex = 2;
            label2.Text = "Şifre :";
            // 
            // txtSifre
            // 
            txtSifre.Location = new Point(673, 381);
            txtSifre.Name = "txtSifre";
            txtSifre.Size = new Size(131, 23);
            txtSifre.TabIndex = 3;
            // 
            // btnGirisYap
            // 
            btnGirisYap.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnGirisYap.Location = new Point(527, 441);
            btnGirisYap.Name = "btnGirisYap";
            btnGirisYap.Size = new Size(139, 28);
            btnGirisYap.TabIndex = 4;
            btnGirisYap.Text = "Giriş Yap";
            btnGirisYap.UseVisualStyleBackColor = true;
            btnGirisYap.Click += btnGirisYap_Click;
            // 
            // btnKayitOl
            // 
            btnKayitOl.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnKayitOl.Location = new Point(690, 484);
            btnKayitOl.Name = "btnKayitOl";
            btnKayitOl.Size = new Size(83, 30);
            btnKayitOl.TabIndex = 5;
            btnKayitOl.Text = "Kaydol";
            btnKayitOl.UseVisualStyleBackColor = true;
            btnKayitOl.Click += btnKayitOl_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label3.Location = new Point(529, 489);
            label3.Name = "label3";
            label3.Size = new Size(137, 20);
            label3.TabIndex = 6;
            label3.Text = "Hesabınız yok mu?";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label4.Location = new Point(627, 271);
            label4.Name = "label4";
            label4.Size = new Size(245, 37);
            label4.TabIndex = 7;
            label4.Text = "KULLANICI GİRİŞİ";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.ChatGPT_Image_2_May_2025_20_17_17;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1508, 824);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(btnKayitOl);
            Controls.Add(btnGirisYap);
            Controls.Add(txtSifre);
            Controls.Add(label2);
            Controls.Add(txtKullanici);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtKullanici;
        private Label label2;
        private TextBox txtSifre;
        private Button btnGirisYap;
        private Button btnKayitOl;
        private Label label3;
        private Label label4;
    }
}
