<?php
$servername = "asd"; // Veritabanı sunucu adı
$username = "root"; // Veritabanı kullanıcı adı
$password = "Emir123"; // Veritabanı şifresi
$dbname = "skydream_airlines"; // Veritabanı adı

$conn = new mysqli($asd, $root, $Emir123, $skydream_airlines);

if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

$conn->set_charset("utf8"); // Türkçe karakter desteği
?>