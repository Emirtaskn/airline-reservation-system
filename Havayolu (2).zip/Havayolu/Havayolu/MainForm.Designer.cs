﻿namespace Havayolu
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbKalkis = new ComboBox();
            cmbVaris = new ComboBox();
            dtpGidis = new DateTimePicker();
            dtpDonus = new DateTimePicker();
            nudYolcu = new NumericUpDown();
            btnUcusAra = new Button();
            dgvUcuslar = new DataGridView();
            btnRezervasyon = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)nudYolcu).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvUcuslar).BeginInit();
            SuspendLayout();
            // 
            // cmbKalkis
            // 
            cmbKalkis.FormattingEnabled = true;
            cmbKalkis.Location = new Point(179, 430);
            cmbKalkis.Margin = new Padding(3, 4, 3, 4);
            cmbKalkis.Name = "cmbKalkis";
            cmbKalkis.Size = new Size(228, 28);
            cmbKalkis.TabIndex = 0;
            // 
            // cmbVaris
            // 
            cmbVaris.FormattingEnabled = true;
            cmbVaris.Location = new Point(179, 468);
            cmbVaris.Margin = new Padding(3, 4, 3, 4);
            cmbVaris.Name = "cmbVaris";
            cmbVaris.Size = new Size(228, 28);
            cmbVaris.TabIndex = 1;
            // 
            // dtpGidis
            // 
            dtpGidis.Location = new Point(179, 509);
            dtpGidis.Margin = new Padding(3, 4, 3, 4);
            dtpGidis.Name = "dtpGidis";
            dtpGidis.Size = new Size(228, 27);
            dtpGidis.TabIndex = 2;
            dtpGidis.ValueChanged += dtpGidis_ValueChanged;
            // 
            // dtpDonus
            // 
            dtpDonus.Location = new Point(179, 557);
            dtpDonus.Margin = new Padding(3, 4, 3, 4);
            dtpDonus.Name = "dtpDonus";
            dtpDonus.Size = new Size(228, 27);
            dtpDonus.TabIndex = 3;
            // 
            // nudYolcu
            // 
            nudYolcu.Location = new Point(178, 606);
            nudYolcu.Margin = new Padding(3, 4, 3, 4);
            nudYolcu.Name = "nudYolcu";
            nudYolcu.Size = new Size(229, 27);
            nudYolcu.TabIndex = 4;
            nudYolcu.ValueChanged += nudYolcu_ValueChanged;
            // 
            // btnUcusAra
            // 
            btnUcusAra.BackColor = Color.SteelBlue;
            btnUcusAra.Cursor = Cursors.Hand;
            btnUcusAra.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnUcusAra.ForeColor = Color.White;
            btnUcusAra.Location = new Point(27, 661);
            btnUcusAra.Margin = new Padding(3, 4, 3, 4);
            btnUcusAra.Name = "btnUcusAra";
            btnUcusAra.Size = new Size(157, 31);
            btnUcusAra.TabIndex = 5;
            btnUcusAra.Text = "Uçuşları Listele";
            btnUcusAra.UseVisualStyleBackColor = false;
            btnUcusAra.Click += btnUcusAra_Click;
            // 
            // dgvUcuslar
            // 
            dgvUcuslar.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvUcuslar.Location = new Point(506, 430);
            dgvUcuslar.Margin = new Padding(3, 4, 3, 4);
            dgvUcuslar.Name = "dgvUcuslar";
            dgvUcuslar.RowHeadersWidth = 51;
            dgvUcuslar.Size = new Size(742, 200);
            dgvUcuslar.TabIndex = 6;
            // 
            // btnRezervasyon
            // 
            btnRezervasyon.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnRezervasyon.Location = new Point(29, 1079);
            btnRezervasyon.Margin = new Padding(3, 4, 3, 4);
            btnRezervasyon.Name = "btnRezervasyon";
            btnRezervasyon.Size = new Size(157, 31);
            btnRezervasyon.TabIndex = 8;
            btnRezervasyon.Text = "Rezervasyon Yap";
            btnRezervasyon.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.Location = new Point(29, 432);
            label1.Name = "label1";
            label1.Size = new Size(128, 23);
            label1.TabIndex = 10;
            label1.Text = " Kalkış Şehri    ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2.Location = new Point(27, 470);
            label2.Name = "label2";
            label2.Size = new Size(134, 23);
            label2.TabIndex = 11;
            label2.Text = " Varış Şehri       ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label3.Location = new Point(27, 513);
            label3.Name = "label3";
            label3.Size = new Size(130, 23);
            label3.TabIndex = 12;
            label3.Text = " Gidiş Tarihi     ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label4.Location = new Point(27, 561);
            label4.Name = "label4";
            label4.Size = new Size(125, 23);
            label4.TabIndex = 13;
            label4.Text = " Dönüş Tarihi  ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label5.Location = new Point(27, 607);
            label5.Name = "label5";
            label5.Size = new Size(121, 23);
            label5.TabIndex = 14;
            label5.Text = " Yolcu Sayısı   ";
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.ChatGPT_Image_2_May_2025_20_27_19;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1336, 1055);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnRezervasyon);
            Controls.Add(dgvUcuslar);
            Controls.Add(btnUcusAra);
            Controls.Add(nudYolcu);
            Controls.Add(dtpDonus);
            Controls.Add(dtpGidis);
            Controls.Add(cmbVaris);
            Controls.Add(cmbKalkis);
            ForeColor = Color.Black;
            Margin = new Padding(3, 4, 3, 4);
            Name = "MainForm";
            Text = "MainForm";
            Load += MainForm_Load;
            ((System.ComponentModel.ISupportInitialize)nudYolcu).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvUcuslar).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbKalkis;
        private ComboBox cmbVaris;
        private DateTimePicker dtpGidis;
        private DateTimePicker dtpDonus;
        private NumericUpDown nudYolcu;
        private Button btnUcusAra;
        private DataGridView dgvUcuslar;
        private Button btnRezervasyon;
        private Label lblBaslik;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
    }
}