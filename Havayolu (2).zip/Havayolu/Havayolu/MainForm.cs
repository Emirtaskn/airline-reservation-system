﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Havayolu
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        private void UcuslariListele()
        {
            string connectionString = "Server=localhost;Database=Havayolu;Uid=root;Pwd=5252;";
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "SELECT * FROM ucus";
                    MySqlDataAdapter da = new MySqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvUcuslar.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Uçuşları listeleme hatası: " + ex.Message);
                }
            }
        }
        private void MainForm_Load(object sender, EventArgs e)
        {
        btnUcusAra.FlatStyle = FlatStyle.Flat;
            List<string> sehirler = new List<string>
    {
        "İstanbul", "Ankara", "İzmir", "Antalya", "Adana",
        "Trabzon", "Gaziantep", "Bursa", "Konya", "Diyarbakır"
    };

            cmbKalkis.Items.AddRange(sehirler.ToArray());
            cmbVaris.Items.AddRange(sehirler.ToArray());

            // Varsayılan olarak ilk şehir seçili olsun
            if (cmbKalkis.Items.Count > 0) cmbKalkis.SelectedIndex = 0;
            if (cmbVaris.Items.Count > 0) cmbVaris.SelectedIndex = 1;
            UcuslariListele();
        }

        private void btnUcusAra_Click(object sender, EventArgs e)
        {
            string kalkisSehri = cmbKalkis.Text;
            string varisSehri = cmbVaris.Text;
            DateTime gidisTarihi = dtpGidis.Value;
            DateTime donusTarihi = dtpDonus.Value;
            int yolcuSayisi = (int)nudYolcu.Value;

            if (string.IsNullOrEmpty(kalkisSehri) || string.IsNullOrEmpty(varisSehri))
            {
                MessageBox.Show("Lütfen kalkış ve varış şehirlerini seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string connectionString = "Server=localhost;Database=Havayolu;Uid=root;Pwd=5252;";
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "INSERT INTO ucus (kalkis_sehri, varis_sehri, gidis_tarihi, donus_tarihi, yolcu_sayisi) " +
                                   "VALUES (@kalkis, @varis, @gidis, @donus, @yolcu)";
                    MySqlCommand cmd = new MySqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@kalkis", kalkisSehri);
                    cmd.Parameters.AddWithValue("@varis", varisSehri);
                    cmd.Parameters.AddWithValue("@gidis", gidisTarihi);
                    cmd.Parameters.AddWithValue("@donus", donusTarihi);
                    cmd.Parameters.AddWithValue("@yolcu", yolcuSayisi);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Uçuş başarıyla kaydedildi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    UcuslariListele();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dtpGidis_ValueChanged(object sender, EventArgs e)
        {

        }

        private void nudYolcu_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
