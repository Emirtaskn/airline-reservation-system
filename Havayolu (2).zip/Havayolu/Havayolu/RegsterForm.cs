﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Havayolu
{
    public partial class RegsterForm : Form
    {
        private MySqlConnection con;
        public RegsterForm()
        {
            InitializeComponent();
            con = new MySqlConnection("Server=localhost;Database=Havayolu;Uid=root;Pwd=5252;");
        }

        private void btnKayitOl_Click(object sender, EventArgs e)
        {
            string kullaniciAdi = txtKullaniciAdi.Text.Trim();
            string sifre = txtSifre.Text.Trim();
            string tc = txtTC.Text.Trim();
            string mail = txtEmail.Text.Trim();

            if (string.IsNullOrEmpty(kullaniciAdi) || string.IsNullOrEmpty(sifre))
            {
                MessageBox.Show("Kullanıcı adı ve şifre boş olamaz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                con.Open();
                string query = "INSERT INTO kullanici (kullanici_adi, sifre, tc, mail) " +
                               "VALUES (@kullaniciAdi, @sifre, @tc, @mail)";
                MySqlCommand cmd = new MySqlCommand(query, con);
                cmd.Parameters.AddWithValue("@kullaniciAdi", kullaniciAdi);
                cmd.Parameters.AddWithValue("@sifre", sifre);
                cmd.Parameters.AddWithValue("@tc", tc);
                cmd.Parameters.AddWithValue("@mail", mail);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Kayıt başarılı! Şimdi giriş yapabilirsiniz.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Form1 loginForm = new Form1();
                loginForm.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

        }
        private void btnGirisDon_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();

            // Form1'i göster
            form1.Show();

            // Şu anki formu kapat
            this.Close();
        }
    }
}
