﻿namespace Havayolu
{
    partial class RegsterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtKullaniciAdi = new TextBox();
            txtEmail = new TextBox();
            txtTC = new TextBox();
            txtSifre = new TextBox();
            btnKayitOl = new Button();
            btnGirisDon = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(46, 67);
            label1.Name = "label1";
            label1.Size = new Size(78, 20);
            label1.TabIndex = 0;
            label1.Text = "Ad-Soyad:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(46, 120);
            label2.Name = "label2";
            label2.Size = new Size(63, 20);
            label2.TabIndex = 1;
            label2.Text = "E-posta:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(46, 173);
            label3.Name = "label3";
            label3.Size = new Size(28, 20);
            label3.TabIndex = 2;
            label3.Text = "TC:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(46, 227);
            label4.Name = "label4";
            label4.Size = new Size(42, 20);
            label4.TabIndex = 3;
            label4.Text = "Şifre:";
            // 
            // txtKullaniciAdi
            // 
            txtKullaniciAdi.Location = new Point(179, 63);
            txtKullaniciAdi.Margin = new Padding(3, 4, 3, 4);
            txtKullaniciAdi.Name = "txtKullaniciAdi";
            txtKullaniciAdi.Size = new Size(228, 27);
            txtKullaniciAdi.TabIndex = 4;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(179, 116);
            txtEmail.Margin = new Padding(3, 4, 3, 4);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(228, 27);
            txtEmail.TabIndex = 5;
            // 
            // txtTC
            // 
            txtTC.Location = new Point(179, 173);
            txtTC.Margin = new Padding(3, 4, 3, 4);
            txtTC.Name = "txtTC";
            txtTC.Size = new Size(228, 27);
            txtTC.TabIndex = 6;
            // 
            // txtSifre
            // 
            txtSifre.Location = new Point(179, 223);
            txtSifre.Margin = new Padding(3, 4, 3, 4);
            txtSifre.Name = "txtSifre";
            txtSifre.Size = new Size(228, 27);
            txtSifre.TabIndex = 7;
            // 
            // btnKayitOl
            // 
            btnKayitOl.Location = new Point(54, 320);
            btnKayitOl.Margin = new Padding(3, 4, 3, 4);
            btnKayitOl.Name = "btnKayitOl";
            btnKayitOl.Size = new Size(86, 31);
            btnKayitOl.TabIndex = 8;
            btnKayitOl.Text = "Kayıt Ol";
            btnKayitOl.UseVisualStyleBackColor = true;
            btnKayitOl.Click += btnKayitOl_Click;
            // 
            // btnGirisDon
            // 
            btnGirisDon.Location = new Point(195, 320);
            btnGirisDon.Margin = new Padding(3, 4, 3, 4);
            btnGirisDon.Name = "btnGirisDon";
            btnGirisDon.Size = new Size(138, 31);
            btnGirisDon.TabIndex = 9;
            btnGirisDon.Text = "Giriş Ekranına Dön";
            btnGirisDon.UseVisualStyleBackColor = true;
            btnGirisDon.Click += btnGirisDon_Click;
            // 
            // RegsterForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(914, 600);
            Controls.Add(btnGirisDon);
            Controls.Add(btnKayitOl);
            Controls.Add(txtSifre);
            Controls.Add(txtTC);
            Controls.Add(txtEmail);
            Controls.Add(txtKullaniciAdi);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "RegsterForm";
            Text = "RegsterForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtKullaniciAdi;
        private TextBox txtEmail;
        private TextBox txtTC;
        private TextBox txtSifre;
        private Button btnKayitOl;
        private Button btnGirisDon;
    }
}