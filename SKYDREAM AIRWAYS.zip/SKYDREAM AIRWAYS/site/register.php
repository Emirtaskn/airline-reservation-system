<?php
header('Content-Type: application/json'); // JSON çıktısı
include 'db_connection.php'; // Veritabanı bağlantısını dahil et

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Şifreyi hash'le
    $tc_kimlik = $_POST['tc_kimlik'];
    $telefon = $_POST['telefon'];

    $stmt = $conn->prepare("INSERT INTO users (name, surname, email, password, tc_kimlik, telefon) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $name, $surname, $email, $password, $tc_kimlik, $telefon);

    if ($stmt->execute()) {
        echo json_encode(array("success" => true));
    } else {
        echo json_encode(array("success" => false, "message" => "Kayıt başarısız"));
    }

    $stmt->close();
}

$conn->close();
?>

<?php
header('Content-Type: application/json');
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $tc_kimlik = $_POST['tc_kimlik'];
    $telefon = $_POST['telefon'];

  
    $stmt_check = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt_check->bind_param("s", $email);
    $stmt_check->execute();
    $stmt_check->store_result();

    if ($stmt_check->num_rows > 0) {
      
        echo json_encode(array("success" => false, "message" => "Bu e-posta adresi zaten kayıtlı."));
    } else {
        
        $stmt_insert = $conn->prepare("INSERT INTO users (name, surname, email, password, tc_kimlik, telefon) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt_insert->bind_param("ssssss", $name, $surname, $email, $password, $tc_kimlik, $telefon);

        if ($stmt_insert->execute()) {
            echo json_encode(array("success" => true));
        } else {
            echo json_encode(array("success" => false, "message" => "Kayıt başarısız."));
        }
        $stmt_insert->close();
    }
    $stmt_check->close();
}

$conn->close();

if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}
?>

<?php
header('Content-Type: application/json');
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $tc_kimlik = $_POST['tc_kimlik'];
    $telefon = $_POST['telefon'];

    // Fotoğraf yükleme (BASİT ÖRNEK - GÜVENLİK İÇİN GELİŞTİRİLMELİDİR!)
    $profil_fotografi = '';
    if (isset($_FILES['profil_fotografi']) && $_FILES['profil_fotografi']['error'] == 0) {
        $hedef_dizin = 'uploads/'; // Yükleme dizini (oluşturulmalı)
        $hedef_dosya = $hedef_dizin . basename($_FILES['profil_fotografi']['name']);
        if (move_uploaded_file($_FILES['profil_fotografi']['tmp_name'], $hedef_dosya)) {
            $profil_fotografi = $hedef_dosya; // Veritabanına dosya yolunu kaydet
        } else {
            echo json_encode(array("success" => false, "message" => "Fotoğraf yüklenirken hata oluştu."));
            exit;
        }
    }

    // E-posta kontrolü (Aynı kalabilir)
    $stmt_check = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt_check->bind_param("s", $email);
    $stmt_check->execute();
    $stmt_check->store_result();

    if ($stmt_check->num_rows > 0) {
        echo json_encode(array("success" => false, "message" => "Bu e-posta adresi zaten kayıtlı."));
    } else {
        $stmt_insert = $conn->prepare("INSERT INTO users (name, surname, email, password, tc_kimlik, telefon, profil_fotografi) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt_insert->bind_param("sssssss", $name, $surname, $email, $password, $tc_kimlik, $telefon, $profil_fotografi);

        if ($stmt_insert->execute()) {
            echo json_encode(array("success" => true));
        } else {
            echo json_encode(array("success" => false, "message" => "Kayıt başarısız."));
        }
        $stmt_insert->close();
    }
    $stmt_check->close();
}

$conn->close();
?>


