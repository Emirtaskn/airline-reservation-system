<?php
header('Content-Type: application/json');
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, name, surname, email, password, profil_fotografi FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            echo json_encode(array(
                "success" => true,
                "name" => $row['name'],
                "surname" => $row['surname'],
                "email" => $row['email'],
                "profil_fotografi" => $row['profil_fotografi']
            ));
        } else {
            echo json_encode(array("success" => false, "message" => "Şifre yanlış"));
        }
    } else {
        echo json_encode(array("success" => false, "message" => "Kullanıcı bulunamadı"));
    }

    $stmt->close();
}

$conn->close();
?>

<?php
header('Content-Type: application/json');
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, name, surname, email, password, profil_fotografi FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            echo json_encode(array(
                "success" => true,
                "name" => $row['name'],
                "surname" => $row['surname'],
                "email" => $row['email'],
                "profil_fotografi" => $row['profil_fotografi']
            ));
        } else {
            echo json_encode(array("success" => false, "message" => "E-posta veya şifre yanlış.")); // Daha genel hata mesajı
        }
    } else {
        echo json_encode(array("success" => false, "message" => "E-posta veya şifre yanlış.")); // Daha genel hata mesajı
    }

    $stmt->close();
}

$conn->close();
?>

<?php
header('Content-Type: application/json');
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, name, surname, email, password, profil_fotografi FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            echo json_encode(array(
                "success" => true,
                "name" => $row['name'],
                "surname" => $row['surname'],
                "email" => $row['email'],
                "profil_fotografi" => $row['profil_fotografi']
            ));
        } else {
            echo json_encode(array("success" => false, "message" => "E-posta veya şifre yanlış."));
        }
    } else {
        echo json_encode(array("success" => false, "message" => "E-posta veya şifre yanlış."));
    }

    $stmt->close();
}

$conn->close();
?>